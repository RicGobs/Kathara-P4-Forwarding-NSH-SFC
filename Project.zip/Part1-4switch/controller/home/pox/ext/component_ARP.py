import pox.openflow.libopenflow_01 as of
from pox.core import core
from pox.lib.addresses import EthAddr
from pox.lib.addresses import IPAddr
from pox.lib.packet.ethernet import ethernet
from pox.lib.packet.arp import arp
import ipaddress

log = core.getLogger()

class Component_ARP:
    def __init__(self) -> None:
        core.openflow.addListeners(self)
        self.network_mask = "255.255.255.0"
        self.gateway_IP = IPAddr("10.0.0.1")
        self.gateway_MAC = EthAddr("11:11:11:11:11:11")


    def _handle_PacketIn(self, event):
        # This method handles ARP requests. By checking if they are directed to the gateway or hosts in the network, it installs flow rules and handles ARP replies.

        packet = event.parsed

        # checks if the packet type is ARP and if the ARP packet is an ARP request
        if packet.type == packet.ARP_TYPE and packet.payload.opcode == arp.REQUEST:
            
            # extracts the ARP payload from the packet
            packet_ARP = packet.payload

            # creates an IPv4 network object using the destination IP address and the network mask
            ip_network = ipaddress.IPv4Network(f"{str(packet.payload.protodst)}/{self.network_mask}", strict=False)

            # checks if the gateway is not in the same network as the destination IP address
            # or if the destination IP address is the same as the gateway IP
            # This is True for ARP request for the gateway
            if ((ipaddress.IPv4Address(str(self.gateway_IP)) not in ip_network) or packet.payload.protodst == self.gateway_IP):
                self.install_ARP_rule(event, packet_ARP, rule=True)
                self._handle_ARP_Request(event, packet_ARP, rule=True)

            # checks if the destination IP address is in the keys of the core.hostDiscovery.hosts
            # This is True for ARP requests for hosts in the network
            elif (packet.payload.protodst in core.hostDiscovery.hosts.keys()):
                self.install_ARP_rule(event,packet_ARP, rule = False)
                self._handle_ARP_Request(event,packet_ARP, rule = False)


    def _handle_ARP_Request(self, event, packet_ARP, rule):
        # This method generates an ARP reply message, encapsulates it in an Ethernet frame, and sends it out as a packet-out message to the switch

        # Creates ARP reply message and set the opcode to indicate that it's an ARP reply
        arp_reply = arp()
        arp_reply.opcode = arp.REPLY

        # sets the source MAC address (hwsrc) of the ARP reply
        if rule:
            # This is True for ARP request for the gateway
            arp_reply.hwsrc = self.gateway_MAC
        else:
            # This is True for ARP requests for hosts in the network
            arp_reply.hwsrc = core.hostDiscovery.hosts[packet_ARP.protodst]["mac"]

        # set the destination MAC address (hwdst) of the ARP reply to the source MAC address (hwsrc) of the received ARP request
        arp_reply.hwdst = packet_ARP.hwsrc

        # swaps the source and destination IP addresses to complete the reply
        arp_reply.protosrc = packet_ARP.protodst
        arp_reply.protodst = packet_ARP.protosrc

        # Create ethernet frame
        ether = ethernet()

        # set its type to ARP
        ether.type = ethernet.ARP_TYPE

        # sets the destination MAC address (dst) of the Ethernet frame to the source MAC address of the received ARP request.
        ether.dst = packet_ARP.hwsrc

        # sets the source MAC address (src) of the Ethernet frame
        if rule:
            # This is True for ARP request for the gateway
            ether.src = self.gateway_MAC
        else:
            # This is True for ARP requests for hosts in the network
            ether.src = core.hostDiscovery.hosts[packet_ARP.protodst]["mac"]

        # sets the payload of the Ethernet frame to the ARP reply message
        ether.payload = arp_reply
        
        # create an OpenFlow packet-out message and send it
        msg = of.ofp_packet_out()
        msg.data = ether.pack()
        msg.actions.append(of.ofp_action_output(port=event.port))
        event.connection.send(msg)


    def install_ARP_rule(self, event, packet_ARP, rule):
        # This method creates an OpenFlow rule to handle ARP reply messages, sets the matching criteria and sends the rule to the OpenFlow switch. The rule includes a timeout.

        # Create an OpenFlow flow modification message, to modify the flow table entries in the OpenFlow switch
        msg = of.ofp_flow_mod()

        # sets the source MAC address (data link src) of the rule
        if rule:
            # This is True for ARP request for the gateway
            dl_src = self.gateway_MAC
        else:
            # This is True for ARP requests for hosts in the network
            dl_src = core.hostDiscovery.hosts[packet_ARP.protodst]["mac"]

        # sets the destination MAC address (data link dst) of the rule to the source MAC address of the received ARP request
        dl_dst = packet_ARP.hwsrc

        # sets timeout of 5 seconds for the rule. After 5 seconds, the rule will be automatically removed from the flow table if it hasn't been matched.
        msg.hard_timeout = 5

        # sets the matching criteria for the rule
        msg.match = of.ofp_match(dl_type=ethernet.ARP_TYPE, dl_src=dl_src, dl_dst=dl_dst)

        # appends an output action to the message
        msg.actions.append(of.ofp_action_output(port=event.ofp.in_port))

        # sends the OpenFlow message (msg) to the connected switch
        event.connection.send(msg)


def launch():
    core.registerNew(Component_ARP)
